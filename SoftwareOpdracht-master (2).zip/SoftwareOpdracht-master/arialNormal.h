#ifndef FONT_INCLUDED
#define FONT_INCLUDED
#include "font.h"

#endif

// Font data for Arial 16pt
extern const char arial_16ptBitmaps[];
extern const FONT_INFO arial_16ptFontInfo;
extern const FONT_CHAR_INFO arial_16ptDescriptors[];
