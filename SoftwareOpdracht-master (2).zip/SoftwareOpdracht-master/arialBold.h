#ifndef FONT_INCLUDED
#define FONT_INCLUDED
#include "font.h"

#endif
// Font data for Arial 16pt
extern const char arialBold_16ptBitmaps[];
extern const FONT_INFO arialBold_16ptFontInfo;
extern const FONT_CHAR_INFO arialBold_16ptDescriptors[];
